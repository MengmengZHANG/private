If want to use babelex in flask admin, should use flask admin version 1.0.9. And recompile zh_CN.po in your site-packages/flask_admin/translations. In url should use lhttp://localhost:5000/admin/?lang=zh.


